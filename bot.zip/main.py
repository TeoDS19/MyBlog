import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timedelta
import json
import os
import csv
from typing import Optional

from flask import Flask
from threading import Thread

app = Flask('')

@app.route('/')
def home():
    return "Bot online"

def run():
    import logging
    log = logging.getLogger('werkzeug')
    log.setLevel(logging.ERROR)
    app.run(host='0.0.0.0', port=8080, use_reloader=False)

def keep_alive():
    print("🔄 Starting Flask keep-alive server...")
    t = Thread(target=run, daemon=True)
    t.start()

keep_alive()

DATA_FILE = "jameson.json"
EXPORT_CSV = "raport_pontaje.csv"

intents = discord.Intents.default()
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

def load_data():
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump({}, f, indent=4)
        return {}

    with open(DATA_FILE, "r", encoding="utf-8") as f:
        raw = json.load(f)

    data = {}
    for uid, info in raw.items():
        start_time = datetime.fromisoformat(info["start_time"]) if info.get("start_time") else None
        afk_start = datetime.fromisoformat(info["afk_start"]) if info.get("afk_start") else None
        total = timedelta(seconds=info.get("total", 0))
        data[uid] = {"start_time": start_time, "afk": info.get("afk", False), "afk_start": afk_start, "total": total}
    return data

def save_data():
    to_save = {}
    for uid, info in pontaje.items():
        to_save[uid] = {
            "start_time": info["start_time"].isoformat() if info.get("start_time") else None,
            "afk_start": info["afk_start"].isoformat() if info.get("afk_start") else None,
            "afk": info.get("afk", False),
            "total": int(info["total"].total_seconds())
        }
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(to_save, f, indent=4, ensure_ascii=False)

def fmt_timedelta(td: timedelta) -> str:
    total_seconds = int(td.total_seconds())
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60
    return f"{hours:d}h {minutes:02d}m {seconds:02d}s"

pontaje = load_data()

class PontajView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="START", style=discord.ButtonStyle.success)
    async def start_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        uid = str(interaction.user.id)
        now = datetime.utcnow()
        info = pontaje.get(uid)
        if info and info.get("start_time"):
            await interaction.response.send_message("🟡 Ai deja o sesiune activă!", ephemeral=True)
            return
        if not info:
            pontaje[uid] = {"total": timedelta(), "start_time": now, "afk": False, "afk_start": None}
        else:
            info["start_time"] = now
            info["afk"] = False
            info["afk_start"] = None
        save_data()
        await interaction.response.send_message("✅ Pontaj pornit!", ephemeral=True)

    @discord.ui.button(label="AFK", style=discord.ButtonStyle.secondary)
    async def afk_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        uid = str(interaction.user.id)
        now = datetime.utcnow()
        info = pontaje.get(uid)
        if not info or not info.get("start_time"):
            await interaction.response.send_message("⚠️ Nu ai o sesiune activă!", ephemeral=True)
            return
        if info.get("afk"):
            await interaction.response.send_message("⚠️ Ești deja în AFK.", ephemeral=True)
            return
        worked = now - info["start_time"]
        info["total"] += worked
        info["start_time"] = None
        info["afk"] = True
        info["afk_start"] = now
        save_data()
        await interaction.response.send_message("😴 Ai intrat în AFK. Timpul activ a fost salvat.", ephemeral=True)

    @discord.ui.button(label="Revenire", style=discord.ButtonStyle.primary)
    async def revenire_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        uid = str(interaction.user.id)
        now = datetime.utcnow()
        info = pontaje.get(uid)
        if not info or not info.get("afk", False):
            await interaction.response.send_message("⚠️ Nu ești în AFK!", ephemeral=True)
            return
        info["afk"] = False
        info["afk_start"] = None
        info["start_time"] = now
        save_data()
        await interaction.response.send_message("✅ Ai revenit din AFK și pontajul a fost reluat.", ephemeral=True)

    @discord.ui.button(label="Închidere", style=discord.ButtonStyle.danger)
    async def stop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        uid = str(interaction.user.id)
        now = datetime.utcnow()
        info = pontaje.get(uid)
        if not info or (not info.get("start_time") and not info.get("afk")):
            await interaction.response.send_message("⚠️ Nu ai un pontaj activ!", ephemeral=True)
            return
        if info.get("start_time"):
            info["total"] += now - info["start_time"]
        info["start_time"] = None
        info["afk"] = False
        info["afk_start"] = None
        save_data()
        await interaction.response.send_message(f"🛑 Pontaj închis. Total acumulat: **{fmt_timedelta(info['total'])}**", ephemeral=True)

    @discord.ui.button(label="VEZI PONTAJ", style=discord.ButtonStyle.gray)
    async def vezi_pontaj(self, interaction: discord.Interaction, button: discord.ui.Button):
        uid = str(interaction.user.id)
        now = datetime.utcnow()
        info = pontaje.get(uid)
        if not info:
            await interaction.response.send_message("ℹ️ Nu ai pontaj activ.", ephemeral=True)
            return
        total = info.get("total", timedelta())
        session = timedelta()
        if info.get("start_time"):
            session = now - info["start_time"]
        total_current = total + session
        lines = [
            f"📊 **Total acumulat:** {fmt_timedelta(total)}",
            f"⏱️ **Sesiune curentă:** {fmt_timedelta(session)}",
            f"🔁 **Total (acum):** {fmt_timedelta(total_current)}",
            f"😴 **În AFK:** {'Da' if info.get('afk') else 'Nu'}"
        ]
        await interaction.response.send_message("\n".join(lines), ephemeral=True)

@bot.tree.command(name="ui_pontaj", description="Afișează UI-ul de pontaj")
async def ui_pontaj(interaction: discord.Interaction):
    embed = discord.Embed(
        title="Pontaj",
        description="Apasă butoanele de mai jos:\n• **START** – pornește pontajul\n• **AFK** – setează pauza\n• **Revenire** – revii din AFK\n• **Închidere** – oprește pontajul curent\n• **VEZI PONTAJ** – afișează total + sesiune curentă",
        color=discord.Color.blurple()
    )
    await interaction.response.send_message(embed=embed, view=PontajView())

@bot.tree.command(name="pontaj", description="Arată totalul tău lucrat")
async def cmd_pontaj(interaction: discord.Interaction):
    uid = str(interaction.user.id)
    now = datetime.utcnow()
    if uid not in pontaje:
        pontaje[uid] = {"start_time": None, "afk": False, "afk_start": None, "total": timedelta()}
        save_data()
        await interaction.response.send_message("ℹ️ Nu aveai pontaj. Apasă START în UI pentru a începe sesiunea.", ephemeral=True)
        return
    info = pontaje[uid]
    total = info["total"]
    if info.get("start_time"):
        total += now - info["start_time"]
    await interaction.response.send_message(f"📊 Total acumulat: **{fmt_timedelta(total)}**", ephemeral=True)

@bot.tree.command(name="pontaj_curent", description="Arată timpul din sesiunea curentă")
async def cmd_pontaj_curent(interaction: discord.Interaction):
    uid = str(interaction.user.id)
    now = datetime.utcnow()
    if uid not in pontaje:
        pontaje[uid] = {"start_time": None, "afk": False, "afk_start": None, "total": timedelta()}
        save_data()
        await interaction.response.send_message("ℹ️ Nu aveai pontaj. Apasă START în UI pentru a începe sesiunea.", ephemeral=True)
        return
    info = pontaje[uid]
    if info.get("afk"):
        afk_dur = now - info.get("afk_start", now)
        await interaction.response.send_message(f"😴 Ești în AFK de: **{fmt_timedelta(afk_dur)}**", ephemeral=True)
    elif info.get("start_time"):
        session = now - info["start_time"]
        await interaction.response.send_message(f"⏱️ Sesiune curentă: **{fmt_timedelta(session)}**", ephemeral=True)
    else:
        await interaction.response.send_message("ℹ️ Nu ai o sesiune activă. Apasă START în UI pentru a începe.", ephemeral=True)

@bot.tree.command(name="pontaj_user", description="[ADMIN] Vezi pontajul unui user")
@app_commands.describe(member="Membru pentru care vrei să vezi pontajul")
@app_commands.checks.has_permissions(administrator=True)
async def cmd_pontaj_user(interaction: discord.Interaction, member: discord.Member):
    uid = str(member.id)
    info = pontaje.get(uid)
    if not info:
        await interaction.response.send_message(f"ℹ️ {member.display_name} nu are pontaj înregistrat.", ephemeral=True)
        return
    total = info.get("total", timedelta())
    if info.get("start_time"):
        total += datetime.utcnow() - info["start_time"]
    await interaction.response.send_message(f"📊 Pontajul lui {member.display_name}: **{fmt_timedelta(total)}**", ephemeral=True)

@bot.tree.command(name="export_pontaje", description="[ADMIN] Exportă toate pontajele în CSV")
@app_commands.checks.has_permissions(administrator=True)
async def cmd_export(interaction: discord.Interaction):
    if not pontaje:
        await interaction.response.send_message("⚠️ Nu există pontaje de exportat.", ephemeral=True)
        return
    with open(EXPORT_CSV, "w", newline="", encoding="utf-8") as csvfile:
        fieldnames = ["User ID", "Nume", "Start Time", "Total (h:m:s)", "În AFK"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for uid, info in pontaje.items():
            member = interaction.guild.get_member(int(uid)) if interaction.guild else None
            start_str = info["start_time"].strftime("%Y-%m-%d %H:%M:%S") if info.get("start_time") else "-"
            total = info["total"]
            if info.get("start_time"):
                total += datetime.utcnow() - info["start_time"]
            writer.writerow({
                "User ID": uid,
                "Nume": member.display_name if member else "Necunoscut",
                "Start Time": start_str,
                "Total (h:m:s)": fmt_timedelta(total),
                "În AFK": "Da" if info.get("afk") else "Nu"
            })
    await interaction.response.send_message("📁 Raport generat:", file=discord.File(EXPORT_CSV), ephemeral=False)

@bot.event
async def on_ready():
    try:
        await bot.tree.sync()
        print("✅ Comenzi slash sincronizate!")
    except Exception as e:
        print(f"❌ Eroare sincronizare: {e}")
    if bot.user:
        print(f"Bot conectat ca {bot.user} (id: {bot.user.id})")

if __name__ == "__main__":
    TOKEN = os.environ.get("TOKEN")
    if not TOKEN:
        print("❌ Eroare: TOKEN nu este setat în environment variables!")
        exit(1)
    bot.run(TOKEN)
